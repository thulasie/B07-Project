package com.example.smartAir.triaging;

public interface HomeController {
    void returnToHome();
}

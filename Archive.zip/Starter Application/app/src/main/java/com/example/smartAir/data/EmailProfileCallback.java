package com.example.smartAir.data;

public interface EmailProfileCallback {
    void onComplete();
}

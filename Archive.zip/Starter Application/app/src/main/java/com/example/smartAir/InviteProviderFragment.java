package com.example.smartAir;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class InviteProviderFragment extends Fragment {
    private Spinner spinnerInvite, spinnerProvider;
    private Button process;
    private FirebaseDatabase db;
    private DatabaseReference parent, provider;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.temp_manage_provider, container, false);
            spinnerInvite = view.findViewById(R.id.spinnerInvite);
            spinnerProvider = view.findViewById(R.id.spinnerPickProvider);
            process = view.findViewById(R.id.buttonInvite);
            db = FirebaseDatabase.getInstance();
            parent = db.getReference("users/parent");
            provider = db.getReference("users/provider");

            //adding provider options into spinner
            //it is set to parentEmail for testing but should be userEmail.toString()
            provider.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    ArrayList<String> providerNames = new ArrayList<String>();
                    providerNames.add("Pick a provider");
                    for(DataSnapshot childSnapShot : snapshot.getChildren()){
                        providerNames.add(childSnapShot.getKey());
                    }
                    setUpSpinner(spinnerProvider, providerNames);
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
            }});

            ArrayList<String> service = new ArrayList<String>();
            service.add("Pick a service");
            service.add("Invite");
            service.add("Revoke");
            setUpSpinner(spinnerInvite, service);

        return view;
    }

    private void setUpSpinner(Spinner spinner, ArrayList<String> list){
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }


}


/*
TODO
setup a layout with two spinners and one button
one spinner will have invite and revoke
one spinner will have provider's email, but for invite, only the one's that I didn't invited
and for revoke, only the one's that I did invited

Once invitation is sent, the getTime() will be used for the code, and if enough time has passed (7 days), the code
will be removed

the code will be saved under parentEmail -> provider -> providerEmail:getTime()
if accepted, invitelink:getTime() will be changed to providerEmail
if not just get rid of it
if invitation is sent, then revoke is possible even if they did not accepted the invite

logic:
make the spinner first

when invitation is made, save the data to firebase, and show parent the code
Then parent will tell provider the code

Then provider enters the code
Check if it matches the data in firebase
if it does, removegetTime() from providerEmail

when revoked, just remove from provider under parent
and remove every child under provider

when accepted the invite assign child under provider with default values

when provider enters the value, check if 7 days has passed by getting the getTime() at the moment and calculating the differences
 */
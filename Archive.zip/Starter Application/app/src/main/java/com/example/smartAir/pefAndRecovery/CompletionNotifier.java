package com.example.smartAir.pefAndRecovery;

interface CompletionNotifier {
    void notifyMonitor();
}

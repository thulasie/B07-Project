package com.example.smartAir.pefAndRecovery;

public interface ExitScreenAction {
    void run();
}

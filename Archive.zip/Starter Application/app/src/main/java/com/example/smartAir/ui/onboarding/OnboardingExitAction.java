package com.example.smartAir.ui.onboarding;

public interface OnboardingExitAction {
    void run();
}

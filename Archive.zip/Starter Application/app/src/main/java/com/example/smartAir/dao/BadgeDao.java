package com.example.smartAir.dao;
/*
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.smartAir.model.Badge;

import java.util.List;

@Dao
public interface BadgeDao {
    @Insert
    long insert(Badge badge);

    @Query("SELECT * FROM badges ORDER BY earned DESC")
    List<Badge> getAll();

    @Update
    void update(Badge badge);
}
*/
package com.example.smartAir.dao;

/*import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;*/

import com.example.smartAir.model.MedicineLog;

import java.util.List;
/*
@Dao
public interface MedicineLogDao {
    @Insert
    long insert(MedicineLog log);

    @Query("SELECT * FROM medicine_logs ORDER BY timestamp DESC")
    List<MedicineLog> getAll();

    @Query("SELECT COUNT(*) FROM medicine_logs WHERE type = :type AND timestamp >= :since")
    int countSince(String type, long since);

    @Update
    void update(MedicineLog log);

    @Delete
    void delete(MedicineLog log);
}
*/
package com.example.smartAir.dao;
/*
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.smartAir.model.InventoryItem;

import java.util.List;

@Dao
public interface InventoryDao {
    @Insert
    long insert(InventoryItem item);

    @Query("SELECT * FROM inventory_items ORDER BY expiryDate ASC")
    List<InventoryItem> getAll();

    @Update
    void update(InventoryItem item);

    @Delete
    void delete(InventoryItem item);
}
*/
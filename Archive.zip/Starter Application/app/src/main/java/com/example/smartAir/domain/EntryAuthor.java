package com.example.smartAir.domain;

public enum EntryAuthor {
    CHILD,
    PARENT
}

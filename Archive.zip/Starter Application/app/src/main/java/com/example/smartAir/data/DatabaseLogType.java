package com.example.smartAir.data;

import com.example.smartAir.pefAndRecovery.Pef;
import com.example.smartAir.triaging.TriageLogEntryData;

public enum DatabaseLogType {
    TRIAGE, MEDICINE, OTHER, PEF, ZONE_CHANGE;
}
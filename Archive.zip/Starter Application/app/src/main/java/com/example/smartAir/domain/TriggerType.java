package com.example.smartAir.domain;

public enum TriggerType {
    EXERCISE,
    COLD_AIR,
    DUST_PETS,
    SMOKE,
    ILLNESS,
    STRONG_ODORS,
    OTHER
}
